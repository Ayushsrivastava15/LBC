import java.util.*;
public class Main
{
	public static void main(String[] args) {
	    Scanner sc = new Scanner(System.in);
	    String s = sc.nextLine();
	    String s2 = sc.nextLine();
	    
	    if(s.equals(s2))
	    System.out.println("equal");
	    else
	    System.out.println("Not equal");
	}
}
