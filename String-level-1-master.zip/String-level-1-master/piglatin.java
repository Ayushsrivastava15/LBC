import java.util.*;
public class Main
{
	public static void main(String[] args) {
	    Scanner sc = new Scanner(System.in);
	    String s = sc.nextLine();
	   for(int i=0;i<s.length();i++)
	   {
	       char ch =s.charAt(i);
	       ch= Character.toLowerCase(ch);
	       if(ch =='a' ||ch =='e' ||ch =='i' ||ch =='o' ||ch =='u' )
	       {System.out.println(s.substring(i)+s.substring(0,i)+"ay");
	       
	           break;
	       }
	   }
	}
}
